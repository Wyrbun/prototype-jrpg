# Prototype JRPG: battle system proof of concept

A greybox prototype of a 3D battle system that mixes Grandia 2 (a shared
timeline with cancels) and Valkyrie Profile 2 (real-time positioning and
per-character combo attacks). Placeholder shapes only, no art yet.

Engine: Godot 4.7 (standard, GDScript), Forward+ renderer.

## Milestones

- [x] 1. Arena: floor, camera, 3 party capsules facing 1 enemy cube
- [x] 2. Timeline bar: icons slide along a bar and whoever reaches the end acts (Space ends a party turn)
- [x] 3. Movement phase: WASD moves one fighter, the world moves only while you do, enemy attack cones, AI allies, shared party AP (earned by moving)
- [x] 4. Telegraphs: walking pushes the timeline; enemies in the casting zone load a skill (Attack/Smash/Defense/Counter), shown on the bar and as a live area; touching a live area or reaching the bar's end fires it (no damage yet)
- [x] 5. Reactions: real-time strikes with a shrinking ring; Parry (E, timed) or Defend (Q, AP, recoverable damage); HP, knockouts, party wipe
- [x] 6. Party attacks: command menu (J) and Legaia-style combo bar paid with AP, per-character combo limit; skill triangle vs stances; enemy HP; victory
- [ ] 7. Cancels, flanking and knockdown: hit a casting enemy from behind to cancel; stagger gauge; knockdown pushes away, disables or reshapes enemy areas
- [ ] 8. One complete fight: win screen, game-over screen

See `docs/battle-design.md` for the full design notes and open questions.

## Project layout

```
scenes/battle/battle_arena.tscn   the battle scene (main scene)
scripts/battle/battle_arena.gd    runs the battle
scripts/battle/combatant.gd       shared by every fighter: name, team, HP, speed, timeline position
scripts/battle/timeline_bar.gd    draws the turn-order bar at the top of the screen
scripts/battle/attack_range.gd    an enemy's area on the floor (dormant or live, reshaped per skill)
scripts/battle/skills.gd          the skill triangle: names, colors, area shapes, damage, windup
scripts/battle/party_status.gd    HP bars (party bottom-left, enemies bottom-right)
scripts/battle/battle_menu.gd     draws the command menu and the combo bar
scripts/battle/moves.gd           the party's attack moves (cost, hits, effects)
docs/battle-design.md             design notes for the battle system
```

## Controls

- WASD or arrow keys: move the fighter you control (party turns only). Walking earns AP (faster the higher your max AP).
- Hold Tab: let time pass without moving (enemies keep moving, AP comes in slowly)
- Space: end the turn
- E: Parry an incoming strike (press when the ring turns gold; +10 max AP, a miss resets max AP)
- Q: Defend against an incoming strike (costs AP)
- J: open the command menu. In menus: W / S to choose, J to select, K to go back
- In the combo bar: J adds the selected move, K removes the last one, Space begins the combo
- While a combo plays: J when the playhead is in a hit's timing box (one per hit) = Perfect (+50% damage, +5 max AP); a wrong press ends the chain and resets max AP; no press costs 5 of the extra max AP
- R: restart the battle (after victory or defeat)

Keys are set in Project > Project Settings > Input Map.

## Conventions

- Forward is -Z in Godot. Each fighter has a small pale "Nose" box on its
  front so you can see which way it faces (this matters for flanking).
- Tuning numbers (HP, speed) are `@export` variables. Change them in the
  Inspector instead of in code.
